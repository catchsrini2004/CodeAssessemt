
const api_url = 
"https://5dc588200bbd050014fb8ae1.mockapi.io/assessment";

// Defining async function
async function getapi(url) {

const response = await fetch(url);
var data = await response.json();
show(data);
}
getapi(api_url);


function show(data) {
let tab = 
  `<tr>
      <th>ID</th>
    <th>User Name</th>
    <th>Avatar</th>
    <th>Created Date</th>
   
   </tr>`;

// Loop to access all rows 
for (let r of data) {
  tab += `<tr> 
<td>${r.id} </td>
<td>${r.name}</td>
<td>${r.createdAt}</td> 
<td><img src="${r.avatar}"/></td>          
</tr>`;
}
// Setting innerHTML as tab variable
document.getElementById("assess").innerHTML = tab;

}