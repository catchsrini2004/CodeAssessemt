const getAboutUsLink = require("code");

let data = [  {
avatar: "https://s3.amazonaws.com/uifaces/faces/twitter/daykiine/128.jpg",
createdAt: "2021-03-31T13:24:14.020Z",
id: "16",
name: "Ryann Wiegand" },
 {
avatar: "https://s3.amazonaws.com/uifaces/faces/twitter/dotgridline/128.jpg",
createdAt: "2021-03-31T14:36:34.443Z",
id: "17",
name: "Waldo Weimann" }];
test("Returns about-us for english language", () => {
    expect(show(data)).toBeTruthy();
});